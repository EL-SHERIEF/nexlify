import Home1 from "./(homes)/home-1/page";
export const metadata = {
  title:
    "Home 1 || Lexend - Full-featured, professional-looking software, saas and startup nextjs template.",
  description:
    "Lexend - Full-featured, professional-looking software, saas and startup nextjs template.",
};
export default function HomePage1() {
  return (
    <>
      <Home1 />
    </>
  );
}
