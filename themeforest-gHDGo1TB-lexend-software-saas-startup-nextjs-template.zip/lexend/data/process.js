export const cards = [
  {
    src: "/assets/images/custom-icons/home-8-icon-01.svg",
    alt: "icon",
    title: "Enrich Data with Context & Risk Management",
  },
  {
    src: "/assets/images/custom-icons/home-8-icon-02.svg",
    alt: "icon",
    title: "Intuitive dashboard for at-a-glance insights",
  },
  {
    src: "/assets/images/custom-icons/home-8-icon-03.svg",
    alt: "icon",
    title: "Automated data analysis and reporting",
  },
  {
    src: "/assets/images/custom-icons/home-8-icon-06.svg",
    alt: "icon",
    title: "Scalable plans to fit any business size",
  },
];

export const steps = [
  {
    number: "1",
    imgSrc: "/assets/images/template/home-10-step-01.svg",
    title: "Download, create account",
    description:
      "Quickly download the app and create your account in seconds. No complicated registrations or lengthy forms—just simple, fast onboarding.",
    minWidth: "min-w-1/4",
  },
  {
    number: "2",
    imgSrc: "/assets/images/template/home-10-step-02.svg",
    title: "Connect with your circle",
    description:
      "Automatically sync your contacts or manually add friends. Our intelligent network helps you connect seamlessly across multiple platforms.",
    minWidth: "min-w-1/4",
  },
  {
    number: "3",
    imgSrc: "/assets/images/template/home-10-step-03.svg",
    title: "Start communicating",
    description:
      "Start chatting, make video calls, and share files instantly. Experience real-time communication with crystal-clear quality and ultimate privacy.",
    minWidth: "min-w-100 lg:min-w-1/4",
  },
];
