export const timelineData = [
  {
    src: "/assets/images/template/timeline-01.png",
    alt: "Where the idea come up of Lexend :)",
    year: "2014",
    description: "Where the idea come up of Lexend :)",
  },
  {
    src: "/assets/images/template/timeline-02.png",
    alt: "Launched our first business that can be created in minutes, build meaningful relationships.",
    year: "2015",
    description:
      "Launched our first business that can be created in minutes, build meaningful relationships.",
  },
  {
    src: "/assets/images/template/timeline-03.png",
    alt: "Opened our new office in Toronto, CA",
    year: "2016",
    description: "Opened our new office in Toronto, CA",
  },
  {
    src: "/assets/images/template/timeline-04.png",
    alt: "Moved to Silicon Valley whereas now we can focus on building out to help our employees.",
    year: "2019",
    description:
      "Moved to Silicon Valley whereas now we can focus on building out to help our employees.",
  },
  {
    src: "/assets/images/template/timeline-05.png",
    alt: "Opened a new office in London, UK.",
    year: "2020",
    description: "Opened a new office in London, UK.",
  },
  {
    src: "/assets/images/template/timeline-06.png",
    alt: "Top-rated software solution for service suppliers.",
    year: "Today",
    description: "Top-rated software solution for service suppliers.",
  },
];
